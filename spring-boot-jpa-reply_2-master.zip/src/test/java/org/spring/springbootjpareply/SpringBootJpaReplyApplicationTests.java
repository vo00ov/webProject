package org.spring.springbootjpareply;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJpaReplyApplicationTests {

	@Test
	void contextLoads() {
	}

}
