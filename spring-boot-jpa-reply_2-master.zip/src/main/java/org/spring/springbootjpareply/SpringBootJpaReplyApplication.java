package org.spring.springbootjpareply;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJpaReplyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpaReplyApplication.class, args);
	}

}
