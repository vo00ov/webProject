package org.spring.springbootjpareply.dto;

import lombok.*;
import org.spring.springbootjpareply.entity.ReplyEntity;


import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class ReplyDto {

    public Long id;
    public String replyWriter;
    public String replyContents;
    public Long boardId;    // BoardEntity의 board_id    // 게시글 조회시
    private LocalDateTime createTime; // 처음 글작성 시간
    private LocalDateTime updateTime;// 글 수정 시간

    public static ReplyDto toReplyDto(ReplyEntity replyEntity, Long boardId) {

        ReplyDto replyDto = new ReplyDto();
        replyDto.setId((replyEntity.getId()));
        replyDto.setReplyWriter(replyEntity.getReplyWriter());
        replyDto.setReplyContents(replyEntity.getReplyContents());
        replyDto.setCreateTime(replyEntity.getCreateTime());
        replyDto.setBoardId(boardId);   // /board/detail/{id}
        return replyDto;
    }
}
